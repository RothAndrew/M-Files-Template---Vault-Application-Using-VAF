﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MFilesAPI;

namespace SanDiegoDemo
{
    public class VaultApplication
    {
		public string CustomMethod()
		{
			return "Hello world!";
		}

		private void StartOperations( Vault vault )
		{
			// Attach debugger. TODO: Remove before release.
			System.Diagnostics.Debugger.Launch();
		}
    }
}
