Place the zip-file in:
\Documents\Visual Studio 2012\Templates\ProjectTemplates\Visual C#