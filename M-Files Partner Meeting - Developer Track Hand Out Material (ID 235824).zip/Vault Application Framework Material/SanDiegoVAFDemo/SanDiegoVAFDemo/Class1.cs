﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MFiles.VAF;
using MFiles.VAF.Common;
using MFilesAPI;

namespace SanDiegoVAFDemo
{
	public class Configuration
	{
		[MFClass( Required = true )]
		public MFIdentifier TestClassID;
	}

    public class VaultApplication: VaultApplicationBase
    {
		[MFConfiguration( "SanDiegoVAFDemo", "config" )]
		private Configuration config = new Configuration() { TestClassID = "FailAlias" };

		[PropertyCustomValue( "PropertyAlias" )]
		private TypedValue CustomValue( PropertyEnvironment env )
		{
			TypedValue typedValue = new TypedValue();
			typedValue.SetValue( MFDataType.MFDatatypeText, "Hello Worldos!" );
			return typedValue;
		}

		[VaultExtensionMethod( "MethodName" )]
		private string Method( EventHandlerEnvironment env )
		{
			// Return the input to the caller.
			return "San Diego " + env.Input + " " + config.TestClassID.ID;
		}

		protected override void StartApplication()
		{
			SysUtils.ReportInfoToEventLog( "Hello event log viewer person" );

			// Start reporting background operations every three seconds.
			//this.BackgroundOperations.StartRecurringBackgroundOperation( 
			//	"Reporter", 
			//	TimeSpan.FromSeconds( 3 ), 
			//	ReportBackgroundOperationsToEventLog 
			//);
		}

		private void ReportBackgroundOperationsToEventLog()
		{
			List<string> names = this.BackgroundOperations.GetBackgroundOperations().Select( op => op.Name ).ToList();

			SysUtils.ReportInfoToEventLog(
				names.Count + " background operations:\n" +
				string.Join( "\n", names.Take( 50 ) )
			);
		}
    }
}
