The first parameter is the path to appdef.xml. The default is the working directory.

The second parameter is the name of local vault, where to install. The default is "Sample Vault".

MFVaultApplicationInstaller will move the contents to work-directory and zip them to create application package. Then i connects to the given local vault, uninstalls the application with the same Guid (if exists) and installs the application.

The code is provided. Feel free to make changes to the code.