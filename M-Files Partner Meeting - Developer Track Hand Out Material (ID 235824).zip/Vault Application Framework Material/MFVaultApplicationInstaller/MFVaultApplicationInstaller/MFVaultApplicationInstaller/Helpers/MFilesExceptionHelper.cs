﻿using System;
using System.Collections.Generic;
using System.Globalization;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;

namespace MotiveHelpers
{
	/// <summary>
	/// This exception represents an error from M-Files.
	/// </summary>
	public static class MFilesExceptionHelper
	{
		// Error code components from winerror.h.
		private const uint SEVERITY_ERROR = 1;
		private const uint FACILITY_ITF = 4;

		/// <summary>
		/// The file has not yet been committed.
		/// </summary>
		/// <remarks>
		/// For example, this error occurs if attempting to download a file
		/// whose upload has not yet been committed.
		/// </remarks>
		public const uint E_MFILES_FILE_NOT_COMMITTED = 181;

		public const uint E_MFILES_INVALID_SESSION = 27;

		/// <summary>
		/// Extracts M-Files error code from error message.
		/// </summary>
		/// <param name="errorMessage">The error message ( e.g. COMException.Message ).</param>
		/// <returns>M-Files error code.</returns>
		public static uint ExtractMFilesErrorCode( string errorMessage )
		{
			// Basic sanity check.
			// TODO: this may not work on all messages. Maybe there is better way.
			int iTempIndex = errorMessage.IndexOf( ".cpp, " );
			if( iTempIndex == -1 )
				throw new FormatException( "Can't parse. Wrong error message format: " + errorMessage );

			// Start of the error code.
			int iErrIndex = errorMessage.IndexOf( " (0x", iTempIndex );
			if( iErrIndex == -1 )
				throw new FormatException( "Can't parse. Wrong error message format: " + errorMessage );
			iErrIndex += 2;

			// End of the error code.
			iTempIndex = errorMessage.IndexOf( ")", iErrIndex );
			if( iTempIndex == -1 )
				throw new FormatException( "Can't parse. Wrong error message format: " + errorMessage );

			// Determine the actual numeric error code.
			return GetMFilesErrorCode( errorMessage.Substring( iErrIndex, iTempIndex - iErrIndex ) );
		}

		/// <summary>
		/// Extracts M-Files error code from hresult code.
		/// </summary>
		/// <param name="sCode">Hresult code in hex ( e.g. "0x8004000B" ).</param>
		/// <returns>M-Files error code.</returns>
		public static uint GetMFilesErrorCode( string sCode )
		{			
			// Remove leading "0x" and parse value.
			uint code = uint.Parse( sCode.Substring( 2 ), NumberStyles.AllowHexSpecifier );

			return GetMFilesErrorCode( code );
		}

		/// <summary>
		/// Extracts M-Files error code from hresult code.
		/// </summary>
		/// <param name="hr">Hresult code.</param>
		/// <returns>M-Files error code.</returns>
		/// <remarks>
		/// See \src\MFRes\ErrorCodesBase.h for more details.
		/// </remarks>
		public static uint GetMFilesErrorCode( uint hr )
		{
			hr ^= ( ( SEVERITY_ERROR << 31 ) | ( FACILITY_ITF << 16 ) );
			return hr;
		}
	}
}
