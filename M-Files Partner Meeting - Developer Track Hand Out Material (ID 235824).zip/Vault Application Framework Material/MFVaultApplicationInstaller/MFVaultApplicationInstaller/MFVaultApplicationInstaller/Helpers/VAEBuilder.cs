﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.IO.Compression;
using MFilesAPI;
using System.IO;
using System.Xml.Linq;

namespace MotiveHelpers
{
	class VAEBuilder
	{
		string workingDir;

		/// <summary>
		/// Creates a vault application builder.
		/// </summary>
		/// <param name="workingDir">The directory to use to build the vault application.</param>
		public VAEBuilder( string workingDir = null )
		{
			this.workingDir = System.Environment.CurrentDirectory + @"\work\";
			if( workingDir != null )
				this.workingDir = workingDir;

			this.workingDir = EnsureTrailingPathSeparator( this.workingDir );

			// Ensure, that the working dir is empty.
			EnsureEmptyDir( this.workingDir );
		}

		public string CreateApplicationPackage( string applicationID, string applicationPath )
		{
			applicationPath = EnsureTrailingPathSeparator( applicationPath );

			string buildDir = EnsureTrailingPathSeparator( this.workingDir + applicationID );

			EnsureEmptyAndCopyFiles( applicationPath, buildDir );

			string appFilePath;
			appFilePath = this.workingDir + applicationID + ".zip";

			// Create Application Zip File.
			ZipFile.CreateFromDirectory( buildDir, appFilePath );
			return appFilePath;
		}
		
		private void EnsureEmptyAndCopyFiles( string applicationPath, string targetPath )
		{
			// Ensure, that the working dir is empty.
			EnsureEmptyDir( targetPath );

			// Copy application to working dir.
			CopyFiles( applicationPath, targetPath );
		}

		/// <summary>
		/// Creates the directory, if it does not exist. Deletes all files from the directory.
		/// </summary>
		/// <param name="dirPath"></param>
		private void EnsureEmptyDir( string dirPath )
		{
			CreateDirIfNotExists( dirPath );
			DeleteAllFiles( dirPath );
		}

		/// <summary>
		/// Creates the directory, if it does not exist.
		/// </summary>
		/// <param name="dirPath">The path to the directory.</param>
		private void CreateDirIfNotExists( string dirPath )
		{
			if( Directory.Exists( dirPath ) == false )
				Directory.CreateDirectory( dirPath );
		}

		/// <summary>
		/// Deletes all files from the directory.
		/// </summary>
		/// <param name="dirPath">The path to the directory.</param>
		private void DeleteAllFiles( string dirPath )
		{
			foreach( string filePath in Directory.GetFiles( dirPath, "*.*", SearchOption.AllDirectories ) )
				File.Delete( filePath );
		}

		/// <summary>
		/// Copies all files from the source directory to the destination directory.
		/// </summary>
		/// <param name="sourceDir">The source directory.</param>
		/// <param name="destinationDir">The destination directory.</param>
		private void CopyFiles( string sourceDir, string destinationDir )
		{
			destinationDir = EnsureTrailingPathSeparator( destinationDir );
			foreach( string filePath in Directory.GetFiles( sourceDir, "*.*", SearchOption.AllDirectories ) )
				File.Copy( filePath, filePath.Replace( sourceDir, destinationDir ), true );
		}

		public static string EnsureTrailingPathSeparator( string path )
		{
			// They're always one character but EndsWith is shorter than
			// array style access to last path character. Change this
			// if performance are a (measured) issue.
			string separator1 = Path.DirectorySeparatorChar.ToString();
			string separator2 = Path.AltDirectorySeparatorChar.ToString();

			// White spaces are always ignored (both heading and trailing)
			path = path.Trim();

			// Argument is always a directory name then if there is one
			// of allowed separators then I have nothing to do.
			if( path.EndsWith( separator1 ) || path.EndsWith( separator2 ) )
				return path;

			// If there is the "alt" separator then I add a trailing one.
			if( path.Contains( separator2 ) )
				return path + separator2;

			// If there is not an "alt" separator I add a "normal" one.
			// It means path may be with normal one or it has not any separator
			// (for example if it's just a directory name). In this case I
			// default to normal as users expect.
			return path + separator1;
		}
	}
}
