﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using MFilesAPI;

namespace MotiveHelpers
{
	public class RetryingVaultConnection
	{
		private VaultOnServer vaultOnServer;
		private Vault privateVault;
		private Func<VaultOnServer, Vault> connectFunction;

		public RetryingVaultConnection( VaultOnServer vaultOnServer, Func<VaultOnServer, Vault> connectFunction )
		{
			// Save parameters.
			this.vaultOnServer = vaultOnServer;
			this.connectFunction = connectFunction;
		}

		public T DoWithReconnect<T>( Func<Vault, T> action )
		{
			// Initial connection to vault.
			if( this.privateVault == null )
				this.privateVault = connectFunction(vaultOnServer);

			int retries = 0;
			while( true )
			{
				try
				{
					++retries;
					return action( privateVault );
				}
				catch( COMException ex )
				{
					if( retries >= 3 )
					{
						throw;
					}
					if( MFilesExceptionHelper.ExtractMFilesErrorCode( ex.Message ) == MFilesExceptionHelper.E_MFILES_INVALID_SESSION )
					{
						// The session is invalid. Reconnect.
						this.privateVault = connectFunction( vaultOnServer );
					}
					else if( IsRetryableMFilesLockError( ex ) == false )
					{
						throw;
					}
				}
			}
		}

		public void DoWithReconnect( Action<Vault> action )
		{
			DoWithReconnect( delegate( Vault vault ) { action( vault ); return 0; } );
		}


		/// <summary>
		/// Resolves if the error is a locking error that may be resolved by retrying the operation.
		/// </summary>
		/// <param name="exception">The exception to check.</param>
		/// <returns>True if the error represents an error that may be prevented by retrying the M-Files operation.</returns>
		public static bool IsRetryableMFilesLockError( Exception exception )
		{
			// Check if the not found error code can be found from the error message.
			if( exception is System.Runtime.InteropServices.COMException )
			{
				// See the full exception text to analyze the origin of the error.
				string fullExceptionText = exception.ToString();

				// These rules are copied from M-Files MCallInLoop.h.

				// E_MFILES_PROBABLY_UPDATE_CONFLICT:
				// A status report has reported an SQL likely lock conflict. (0x800403F9) 
				if( fullExceptionText.Contains( "(0x800403F9)" ) )
					return true;

				// E_MFILES_PROBABLY_UPDATE_CONFLICT_AUTO_ROLLBACK:
				// A SQL update statement probably resulted in a lock conflict. Try performing the operation again. (0x80040454)
				if( fullExceptionText.Contains( "(0x80040454)" ) )
					return true;

				// Firebird-specific lock conflict indication.
				// 'update conflicts with concurrent update'
				// 'IBCODE=isc_no_dup'
				// 'lock conflict on no wait transaction'
				// 'attempt to store duplicate value' AND 'IX_PV_'
				if( fullExceptionText.Contains( "update conflicts with concurrent update" ) )
					return true;
				if( fullExceptionText.Contains( "IBCODE=isc_no_dup" ) )
					return true;
				if( fullExceptionText.Contains( "lock conflict on no wait transaction" ) )
					return true;
				if( fullExceptionText.Contains( "attempt to store duplicate value" ) && fullExceptionText.Contains( "IX_PV_" ) )
					return true;

				// - The object is locked. Try again later. (0x80040041)
				if( fullExceptionText.IndexOf( "(0x80040041)" ) != -1 )
					return true;

				// SQL Server specific lock conflict indication.
				// These rules are copied from M-Files SQLHelper.cpp.
				if( IsMSSQLServerErrorCode( fullExceptionText, 3960 ) )
					return true;
				if( IsMSSQLServerErrorCode( fullExceptionText, 3961 ) )
					return true;
				if( IsMSSQLServerErrorCode( fullExceptionText, 1205 ) )
					return true;
				if( IsMSSQLServerErrorCode( fullExceptionText, 1203 ) )
					return true;
				if( IsMSSQLServerErrorCode( fullExceptionText, 1204 ) )
					return true;
				if( IsMSSQLServerErrorCode( fullExceptionText, 1221 ) )
					return true;
				if( IsMSSQLServerErrorCode( fullExceptionText, 1222 ) )
					return true;
				if( IsMSSQLServerErrorCode( fullExceptionText, 2601 ) && fullExceptionText.Contains( "IX_PV_" ) )
					return true;


				// Connection loss on SQL Server.
				// These rules are copied from M-Files SQLHelper.cpp.

				// The service has encountered an error processing your request. Please try again.
				if( IsMSSQLServerErrorCode( fullExceptionText, 40197 ) )
					return true;

				// The service is currently busy. Retry the request after 10 seconds.
				if( IsMSSQLServerErrorCode( fullExceptionText, 40501 ) )
					return true;

				// Session is terminated because you have a long-running transaction. Try shortening your transaction.
				if( IsMSSQLServerErrorCode( fullExceptionText, 40549 ) )
					return true;

				// Database '%.*ls' on server '%.*ls' is not currently available. Please retry the connection later.
				if( IsMSSQLServerErrorCode( fullExceptionText, 40613 ) )
					return true;

				// A connection was successfully established with the server, but then an error occurred during
				// the login process.
				if( IsMSSQLServerErrorCode( fullExceptionText, 64 ) )
					return true;

				// The client was unable to establish a connection because of an error during connection
				// initialization process before login.
				if( IsMSSQLServerErrorCode( fullExceptionText, 233 ) )
					return true;

				// This might occur because the permission cache entries for the Server object are initialized
				// during the connection process. During this process, the SQL Server login is not a member of the
				// sysadmin fixed server role. You experience 100 percent CPU utilization occurs when the permission
				// cache for the Server object is initialized.
				// For more information: http://support.microsoft.com/kb/934751/en-us
				if( IsMSSQLServerErrorCode( fullExceptionText, 258 ) )
					return true;

				// A transport-level error has occurred when receiving results from the server. An established
				// connection was aborted by the software in your host machine.
				if( IsMSSQLServerErrorCode( fullExceptionText, 10053 ) )
					return true;

				// A transport-level error has occurred when sending the request to the server. (provider: TCP
				// Provider, error: 0 - An existing connection was forcibly closed by the remote host.)
				if( IsMSSQLServerErrorCode( fullExceptionText, 10054 ) )
					return true;

				// A network-related or instance-specific error occurred while establishing a connection to SQL
				// Server. The server was not found or was not accessible. 
				if( IsMSSQLServerErrorCode( fullExceptionText, 10060 ) )
					return true;

				// "SMux Provider: Physical connection is not usable [xFFFFFFFF]. (ERROR: -1, SQLSTATE: 08S02)"

				// "Session Provider: Physical connection is not usable [xFFFFFFFF]"?
				if( fullExceptionText.Contains( "SMux" ) &&
							fullExceptionText.Contains( "xFFFFFFFF" ) &&
							fullExceptionText.Contains( "SQLSTATE: 08S02" ) )
					return true;

				// "Catastrophic failure (Communication link failure (ERROR: -1, SQLSTATE: 08S01))"
				if( fullExceptionText.Contains( "Communication link failure" ) )
					return true;

				// "Catastrophic failure (Communication link failure (ERROR: -1, SQLSTATE: 08S01))"
				if( fullExceptionText.Contains( "Physical connection is not usable" ) )
					return true;
			}

			// Other error.
			return false;
		}

		/// <summary>
		///  Resolves if the error string represents certain SQL server error.
		/// </summary>
		/// <param name="errors">The error as string.</param>
		/// <param name="codeToTest">The SQL server error code to test.</param>
		/// <returns></returns>
		private static bool IsMSSQLServerErrorCode( string errors, int codeToTest )
		{
			// Check agains error codes in two formats.
			if( errors.Contains( String.Format( "ERROR: {0}", codeToTest ) ) )
				return true;
			if( errors.Contains( String.Format( "ERROR {0}", codeToTest ) ) )
				return true;
			return false;
		}

	}
}
