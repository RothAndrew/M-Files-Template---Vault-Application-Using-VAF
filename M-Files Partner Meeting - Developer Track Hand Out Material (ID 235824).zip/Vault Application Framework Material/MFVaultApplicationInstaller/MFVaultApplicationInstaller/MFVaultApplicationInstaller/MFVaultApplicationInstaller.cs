﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Runtime.InteropServices;
using System.Text;
using System.Threading.Tasks;
using MFilesAPI;
using MotiveHelpers;

namespace MFVaultApplicationInstaller
{
	class MFVaultApplicationInstaller
	{
		// The path for the dll files and the appdef.xml.
		static DirectoryInfo ApplicationPath;

		// The vault to install the package.
		static string TestVaultName = "Sample Vault";

		// The guid of the application.
		private static string ApplicationGuid;

		public static void RunTests( Vault vault )
		{
			// Implement your own tests here.

			// Example: Call an extension method.
			//Console.WriteLine( "Calling the vault extension method." );
			//Console.WriteLine( "Result:" );
			//Console.WriteLine( vault.ExtensionMethodOperations.ExecuteVaultExtensionMethod( "SomeExtensionMethod", "Parameter" ) );
			//Console.WriteLine();
		}

		/// <summary>
		/// Simple program to create the application package and install it to the server.
		/// </summary>
		/// <param name="args"></param>
		static void Main( string[] args )
		{
			try
			{
				// The first argument is the directory of the vault application. Use current directory, if missing.
				if( args.Length >= 1 )
					ApplicationPath = new DirectoryInfo( args[ 0 ] );
				else
					ApplicationPath = new DirectoryInfo( System.Environment.CurrentDirectory );

				// The second argument is the name of the vault. Use default Sample Vault if missing.
				if( args.Length >= 2 )
					TestVaultName = args[ 1 ];

				// Run the program.
				Run();

			}
			catch( Exception ex )
			{
				Console.WriteLine( ex.Message );
			}

			Console.WriteLine( "All done!" );
			Console.ReadKey();
		}

		/// <summary>
		/// The main program logic.
		/// </summary>
		private static void Run()
		{
			Console.WriteLine( "Creating vault application package..." );

			// Initialize vault application builder with the working directory.
			VAEBuilder builder = new VAEBuilder();

			// Get application guid from path.
			MFVaultApplicationInstaller.ApplicationGuid = GetApplicationGuid();

			// Create the application package with the builder.
			string ApplicationPackagePath = builder.CreateApplicationPackage( ApplicationGuid, ApplicationPath.ToString() );

			Console.WriteLine( "Application package created: " + ApplicationPackagePath );
			Console.WriteLine( "Connecting to the server..." );

			// Connect to M-Files Server.
			MFilesServerApplication server = new MFilesServerApplication();
			server.Connect();
			//server.Connect( MFAuthType.MFAuthTypeSpecificMFilesUser, "Test", "t" );

			// Get the vault by name.
			VaultOnServer vaultOnServer = GetLocalVaultOnServer( TestVaultName, server );

			// Initialize vault connection helper. Login as the current user (default).
			RetryingVaultConnection vaultConnection = new RetryingVaultConnection( vaultOnServer, vos => vos.LogIn() );

			// Prompt user for installation.
			//Console.WriteLine("Confirm installation to the local vault: " + TestVaultName + ". (y/n)");

			// If user selected yes, install to the vault.
			//if (UserPressesY())
			ReinstallVAE( ApplicationPackagePath, server, vaultOnServer, vaultConnection );

			// Prompt user for installation.
			//Console.WriteLine("Do you want to run tests. (y/n)");

			// If user selected yes, install to the vault.
			//if (UserPressesY())
			RunTestsWithReconnect( vaultConnection );
		}

		/// <summary>
		/// Reads the application guid from appdef.xml.
		/// </summary>
		/// <param name="applicationPath"></param>
		/// <returns></returns>
		private static string GetApplicationGuid()
		{
			// Read the guid from appdef.xml
			string appdefPath = ApplicationPath.ToString() + Path.DirectorySeparatorChar + "appdef.xml";

			if( File.Exists( appdefPath ) == false )
				throw new FileNotFoundException( "appdef.xml not found in: " + appdefPath );

			return System.Xml.Linq.XDocument.Load( appdefPath ).Root.Element( "guid" ).Value;
		}

		/// <summary>
		/// Gets the local vault on server.
		/// </summary>
		/// <param name="vaultName"></param>
		/// <param name="server"></param>
		/// <param name="vaultOnServer"></param>
		/// <returns></returns>
		private static VaultOnServer GetLocalVaultOnServer( string vaultName, MFilesServerApplication server )
		{
			try
			{
				return server.GetOnlineVaults().GetVaultByName( vaultName );
			}
			catch( Exception e )
			{
				Console.WriteLine( "Cannot install to local vault: " + vaultName );
				Console.WriteLine( e.ToString() );
			};

			return null;
		}

		/// <summary>
		/// Installs the application in given path uninstalling any previous application.
		/// </summary>
		/// <param name="vaultApplicationEngineGuid"></param>
		/// <param name="appFilePath"></param>
		/// <param name="server"></param>
		/// <param name="vaultOnServer"></param>
		/// <param name="vaultConnection"></param>
		private static void ReinstallVAE( string appFilePath, MFilesServerApplication server, VaultOnServer vaultOnServer, RetryingVaultConnection vaultConnection )
		{
			Console.WriteLine( "Checking for previous installations of the application..." );

			if( vaultConnection.DoWithReconnect( vault => IsVAEInstalled( vault ) ) )
			{
				Console.WriteLine( "Found." );
				Console.WriteLine( "Uninstalling the previous installation of the application..." );

				UninstallVAE( server, vaultOnServer, vaultConnection );
			}

			Console.WriteLine( "Installing the application..." );

			// Install application.
			vaultConnection.DoWithReconnect( vault => vault.CustomApplicationManagementOperations.InstallCustomApplication( appFilePath ) );

			Console.WriteLine( "Installed." );
			Console.WriteLine( "Restarting the vault..." );

			// The new version was installed. Restart the vault.
			server.VaultManagementOperations.TakeVaultOffline( vaultOnServer.GUID, true );
			server.VaultManagementOperations.BringVaultOnline( vaultOnServer.GUID );
		}

		/// <summary>
		/// Uninstalls VAE from the given vault.
		/// </summary>
		/// <param name="server"></param>
		/// <param name="vaultOnServer"></param>
		/// <param name="vaultConnection"></param>
		private static void UninstallVAE( MFilesServerApplication server, VaultOnServer vaultOnServer, RetryingVaultConnection vaultConnection )
		{
			// Try to uninstall.
			if( vaultConnection.DoWithReconnect( vault => TryUninstallCustomApplication( vault, MFVaultApplicationInstaller.ApplicationGuid ) ) )
			{
				Console.WriteLine( "Uninstalled." );
				Console.WriteLine( "Restarting the vault..." );

				// The previous version was uninstalled. Restart the vault.
				server.VaultManagementOperations.TakeVaultOffline( vaultOnServer.GUID, true );
				server.VaultManagementOperations.BringVaultOnline( vaultOnServer.GUID );
			}
		}

		/// <summary>
		/// Run some tests with reconnect
		/// </summary>
		/// <param name="vaultConnection"></param>
		private static void RunTestsWithReconnect( RetryingVaultConnection vaultConnection )
		{
			Console.WriteLine( "Running tests..." );

			// Test connection to vault to prevent multiple calls RunTests, when the vault connection is broken.
			vaultConnection.DoWithReconnect( vault => vault.TestConnectionToVault() );

			// Test extension method.
			vaultConnection.DoWithReconnect( vault => RunTests( vault ) );
		}

		private static bool UserPressesY()
		{
			bool isYPressed = Console.ReadKey().KeyChar == 'y';
			Console.WriteLine();
			return isYPressed;
		}

		private static bool IsVAEInstalled( Vault vault )
		{
			try
			{
				vault.CustomApplicationManagementOperations.GetCustomApplication( MFVaultApplicationInstaller.ApplicationGuid );
			}
			catch( COMException comException )
			{
				// Silently skip if not found.
				if( IsMFilesNotFoundError( comException ) )
					return false;

				// Throw all other errors.
				throw;
			}

			return true;
		}

		/// <summary>
		/// Tries to uninstall the custom application.
		/// </summary>
		/// <param name="vault">The vault.</param>
		/// <param name="appID">The ID (GUID) of the application.</param>
		/// <returns>True, if the application was found and removed. False, if the application was not found.</returns>
		private static bool TryUninstallCustomApplication( Vault vault, string appID )
		{
			try
			{
				// Uninstall the application.
				vault.CustomApplicationManagementOperations.UninstallCustomApplication( appID );
			}
			catch( COMException comException )
			{
				// Silently skip if not found.
				if( IsMFilesNotFoundError( comException ) )
					return false;

				// Throw all other errors.
				throw;
			}

			return true;
		}

		/// <summary>
		/// Checks if the exception is a 'not found' error.
		/// </summary>
		/// <param name="exception">The exception that should be checked.</param>
		/// <returns></returns>
		public static bool IsMFilesNotFoundError( Exception exception )
		{
			// Check if the not found error code can be found from the error message.
			if( exception is System.Runtime.InteropServices.COMException )
			{
				if( exception.Message.IndexOf( "(0x8004000B)" ) != -1 ||
					exception.Message.IndexOf( "(0x800408A4)" ) != -1 )
					return true;
			}

			// The error was other than the 'not found'.
			return false;
		}
	
	}
}
