﻿// **************************************************** //
// *********** Vault Element ID Resolver ************* //

function VaultID(vault) {
    /// <summary>M-Files Object Version Extension Wrapper</summary>
    ///	<param name="Vault" type="MFilesAPI.Vault"></param>

    // Self Scope
    var self = this;
    
    // Create enum-like object for dot syntax
    this.StructureType = { Object: "ObjType", Class: "ObjectClass", Property: "PropertyDef", Workflow: "Workflow", State: "State" };

    // Retrieve a cached instance in the Vault if it exists.
    if (this.vault && this.vault.VaultID)
        return vault.VaultID;

    // Setup this instance.
    this.vault = vault;

    // Add a Vault extension method.
    this.vault.resolveID = function (type, ref) {
        return self.Resolve(self.vault, type, ref);
    }

    // Add a Vault extension method.
    this.id = function (type, ref) {
        return self.Resolve(self.vault, type, ref);
    }

    // return self
    return this;
}

VaultID.prototype = {
    Resolve: function (vault, type, alias) {
        /// <summary>Resolves the id of the type by alias.</summary>
        ///	<param name="type" type="StructureType">Structure Type</param>
        ///	<param name="alias">referenced item alias</param>

        // ensure there is an alias provided
        if (!alias)
            return -1;

        // if this is a number return as is...
        if (this.IsNumber(alias)) return alias;

        // Determine the passed type
        switch (type) {
            case this.StructureType.Object:
                return this.vault.ObjectTypeOperations.GetObjectTypeIDByAlias(alias);
            case this.StructureType.Class:
                return this.vault.ClassOperations.GetObjectClassIDByAlias(alias);
            case this.StructureType.Property:
                return this.vault.PropertyDefOperations.GetPropertyDefIDByAlias(alias);
            case this.StructureType.Workflow:
                return this.vault.WorkflowOperations.GetWorkflowIDByAlias(alias);
            case this.StructureType.State:
                return this.vault.WorkflowOperations.GetWorkflowStateIDByAlias(alias);
            default:
        }

        // if we have not returned anything yet, return the alias
        return alias;
    },

    IsNumber: function (value) {
        /// <summary>
        /// Determines is the Value of the passes parameter is numeric.
        /// </summary>
        /// <param name="value">Object to check.</param>
        /// <returns>The True or False.</returns>

        return !isNaN(parseFloat(value)) && isFinite(value);
    },

    Create: function (type) {
        return MFiles.CreateInstance(type);
    }
}