// ********************************************************************** //
// ***************************** CustomUxUtil ********************************* //

function CustomUxUtil(shellUI, serverAppNamespace, paneDebug, httpDebuger) {
    /// <summary>Manages Dashboard operations.</summary>
    /// <field name="shellUI" type="MFilesAPI.ShellUI">The current shell UI.</field>
    /// <field name="serverNamespace" type="string">true => debugger is launched in the Right Pane || false => Debugger in launched in Pop-up Dashboard</field>
    /// <field name="paneDebug" type="bool">Determine the location of the launched Debugging Console</field>

    // Used in Vault Extension Method Calls
    this.ServerApp_Namespace = serverAppNamespace || "";

    // Store the ShellUI locally
    this.ui = shellUI;

    // Store the ShellFrame locally
    this.frame = null;

    if (httpDebuger) {    
        // try to create a web client    
        try {
            // Create a Web Client from a .NET DLL
            this.webClientLite = MFiles.CreateObjectCLR("util\\HttpApi.dll", "HttpApi.WebClientLite");
        } catch(ex) {
            // log the HTTP Debug failure
            this.Debug(ex.message);
        }
    };

    // Enum-Like Objects to provide a dot syntax
    this.MDStructure = { All: "MFMetadataStructureItemAll", Class: "MFMetadataStructureItemClass", ClassGroup: "MFMetadataStructureItemClassGroup", ACL: "MFMetadataStructureItemNamedACL", None: "MFMetadataStructureItemNone", ObjectType: "MFMetadataStructureItemObjectType", PropertyDef: "MFMetadataStructureItemPropertyDef", State: "MFMetadataStructureItemState", User: "MFMetadataStructureItemUser", UserGroup: "MFMetadataStructureItemUserGroup", ValueList: "MFMetadataStructureItemValueList", ValueListItem: "MFMetadataStructureItemValueListItem", EventHandler: "MFMetadataStructureItemVaultEventHandler", View: "MFMetadataStructureItemViewDef", Workflow: "MFMetadataStructureItemWorkflow" };
    this.BuiltInCommands = { AddCollectionMember: 95,  AddDashboardToViewLocBottom: 69,  AddDashboardToViewLocMain: 67,  AddDashboardToViewLocRight: 68,  AddDocumentFromScanner: 43,  AddFileFromScanner: 44,  AddGroupingLevel: 116,  AddRelationship: 98,  AddReportToViewLocBottom: 69,  AddReportToViewLocMain: 67,  AddReportToViewLocRight: 68,  AddShortcutToTaskPane: 66,  AddToFavorites: 62,  ALL: 268435455,  Applications: 136,  BeginCoauthoring: 130,  BottomPane_Minimized: 152,  BottomPane_Normal: 151,  BottomPane_Off: 153,  BrowseInThisWindow: 120,  ChangeLanguage: 42,  ChangePassword: 41,  ChangeState: 26,  ChangeViewMode: 106,  CheckIn: 11,  CheckInWithComments: 12,  CheckOut: 10,  CheckOutForCoauthoring: 129,  ChooseColumns: 83,  CleanView: 58,  ClearArchiveMarker: 29,  ClearLocalCache: 40,  ClientSettings: 37,  CompleteAssignment: 25,  ConvertToDocument: 6,  ConvertToDocumentFiles: 7,  ConvertToMultiFilePDF: 82,  ConvertToOneMultiFileDocument: 32,  ConvertToSearchablePDF: 46,  ConvertToSingleFileDocument: 31,  ConvertToSingleFilePDF: 81,  Copy: 73,  CreateOrGetShortcut: 64,  CreateShortcut: 65,  CurrentGroupingLevel: 117,  CustomizePropertyFolder: 144,  Cut: 74,  Delete: 76,  DeleteAll: 90,  Destroy: 91,  EditCollectionMembership: 96,  EditOneAnnotation: 159,  EditRelationship: 99,  EndCoauthoring: 131,  ExportObjects: 79,  ExportSearchBarConditions: 80,  FIRST: 1,  GoOffline: 35,  GoOnline: 34,  GoToCustomView: 124,  GroupBy: 121,  GroupFoldersBy: 122,  GroupFoldersByFirstLetters: 115,  GroupObjectsByFirstLetters: 114,  GroupObjectsByObjectType: 54,  GroupViewsAndFolders: 55,  HideAllVisualAnnotations: 158,  HideOrShowEmptyFolders: 119,  HideView: 56,  HitHighlighting: 128,  ImportFilesAndFolders: 8,  InvertSelection: 86,  LabelThisVersion: 93,  LAST: 162,  LogOut: 36,  MakeCopy: 9,  MarkComplete: 123,  MarkFolderForOfflineAvailability: 15,  MarkForArchiving: 28,  MarkForOfflineAvailability: 16,  MFilesGuidedTour: 142,  MFilesHelp: 141,  ModifyVersionDetails: 92,  NavigationPane_Off: 155,  NavigationPane_On: 154,  NewAnnotation: 161,  NewAssignment: 23,  NewObject: 87,  NewOfflineFilter: 3,  NewPropertyFolder: 5,  NewSubobject: 94,  NewTraditionalFolder: 4,  NewView: 2,  NewWindow: 78,  NotificationSettings: 39,  Paste: 75,  PasteAsMultiFileDocument: 84,  Properties: 14,  Refresh: 88,  RemoveCollectionMembership: 97,  RemoveCurrentGroupingLevel: 118,  RemoveDashboardFromViewLocBottom: 72,  RemoveDashboardFromViewLocMain: 70,  RemoveDashboardFromViewLocRight: 71,  RemoveFromFavorites: 63,  RemoveOfflineAvailability: 17,  RemoveRelationship: 100,  RemoveReportFromViewLocBottom: 72,  RemoveReportFromViewLocMain: 70,  RemoveReportFromViewLocRight: 71,  Rename: 77,  ReplaceWithFile: 33,  ReplaceWithFileFromScanner: 45,  ResetUISettingsToDefaults: 60,  ResolveConflictDiscardThis: 135,  ResolveConflictKeepThis: 134,  RightPane_Minimized: 149,  RightPane_Normal: 148,  RightPane_Off: 150,  RollBack: 89,  SaveAnnotation: 160,  SaveAsCommonUISettings: 61,  SaveAsPDF: 50,  SelectAll: 85,  SendCoauthoringLink: 133,  SendCopyByEmail: 48,  SendLinkByEmail: 47,  SendPDFByEmail: 49,  ServerAdmin: 38,  ShareViaSkyDrive: 137,  ShareViaSkyDriveAsPDF: 138,  ShowAllVisualAnnotations: 157,  ShowAssignments: 24,  ShowBottomPane: 52,  ShowCollectionMembers: 20,  ShowComments: 22,  ShowHistory: 18,  ShowMetadataInBottomPane: 140,  ShowMetadataInRightPane: 139,  ShowNavigationPane: 143,  ShowOriginalObject: 132,  ShowPreviewPane: 53,  ShowPropertiesPane: 52,  ShowRelationships: 19,  ShowRightPane: 53,  ShowVisualAnnotations: 156,  SubMenu_Archiving: 109,  SubMenu_BrowseRelatedObjects: 108,  SubMenu_Dashboards: 113,  SubMenu_DisplayMode: 105,  Submenu_DocumentX: 127,  SubMenu_NewFile: 102,  SubMenu_NewObject: 101,  SubMenu_OfflineAvailability: 107,  SubMenu_RefreshExtObjects: 112,  SubMenu_Reports: 113,  SubMenu_ScanningAndOCR: 111,  SubMenu_Send: 104,  Submenu_VaultX: 125,  Submenu_ViewX: 126,  SubMenu_WindowsCommands: 103,  SubMenu_Workflow: 110,  SubstituteUsers: 51,  UncustomizePropertyFolder: 145,  Undefined: 0,  Undelete: 30,  UndoCheckOut: 13,  UnhideView: 57,  UnhideViews: 59,  UseCompactLayout: 147,  UseNormalLayout: 146,  ViewEditSubobjects: 21,  Workflow: 27 };
    this.Events = { ActiveListingChanged: 17, AddObjectFile: 50, AddObjectsToFavorites: 78, AddObjectToFavorites: 76,  BuiltInCommand: 22, ChangeVaultLanguage: 97, CheckInObject: 56, CheckInObjects: 58, CheckOutObject: 60, CheckOutObjects: 62, CloseWindow: 30, ContentChanged: 25, ContentInitialize: 132, CreateObject: 32, CustomCommand: 22, DestroyObject: 34, DestroyObjects: 36, DestroyObjectVersion: 38, DestroyObjectVersions: 40, HidePane: 5, HideTab: 147, InitializingContent: 131, ListingActivated: 28, ListingDeactivated: 29, LoggedIn: 99, LogOut: 96, MinimizedStateChanged: 21, ModifyObjectVersionLabels: 84, NewBottomPane: 12, NewCommands: 16, NewCommonDialogShellFrame: 9, NewEmbeddedShellFrame: 10, NewNormalShellFrame: 8, NewRightPane: 14, NewSearchPane: 13, NewShellFrame: 7, NewShellListing: 15, NewTab: 18, NewTaskPane: 11, NewVaultEntry: 31, Notification: 1, ObjectAddedToFavorites: 77, ObjectCheckedIn: 57, ObjectCheckedOut: 61, ObjectCheckoutsUndone: 67, ObjectCheckoutUndone: 65, ObjectCreated: 33, ObjectDestroyed: 35, ObjectFileAdded: 51, ObjectFileRemoved: 53, ObjectFileRenamed: 55, ObjectLevelPropertySet: 87, ObjectOfflineAvailabilityRemoved: 91, ObjectOfflineAvailabilitySet: 90, ObjectRemoved: 43, ObjectRemovedFromFavorites: 81, ObjectsAddedToFavorites: 79, ObjectsCheckedIn: 59, ObjectsCheckedOut: 63, ObjectsDestroyed: 37, ObjectsRemoved: 45, ObjectsRemovedFromFavorites: 83, ObjectsUndeleted: 49, ObjectUndeleted: 47, ObjectVersionDestroyed: 39, ObjectVersionLabelsModified: 85, ObjectVersionPermissionsSet: 75, ObjectVersionRolledBack: 69, ObjectVersionsDestroyed: 41, PaneResized: 6, PropertiesOfObjectVersionSet: 71, PropertiesOfObjectVersionsSet: 73, RemoveObject: 42, RemoveObjectFile: 52, RemoveObjectFromFavorites: 80, RemoveObjectOfflineAvailability: 89, RemoveObjects: 44, RemoveObjectsFromFavorites: 82, RenameObjectFile: 54, RollBackObjectVersion: 68, SelectedItemsChanged: 24, SelectionChanged: 23, SetObjectLevelProperty: 86, SetObjectOfflineAvailability: 88, SetObjectVersionPermissions: 74, SetPropertiesOfObjectVersion: 70, SetPropertiesOfObjectVersions: 72, ShowContextMenu: 26, ShowMainMenu: 27, ShowPane: 4, ShowTab: 146, Started: 2, Stop: 3, SwitchedToOfflineMode: 93, SwitchedToOnlineMode: 95, SwitchToOfflineMode: 92, SwitchToOnlineMode: 94, TabSelected: 19, TabUnselected: 20, Undefined: 0, UndeleteObject: 46, UndeleteObjects: 48, UndoObjectCheckout: 64, UndoObjectCheckouts: 66 };
    this.CommandStates = { Active: 1, Inactive: 2, Hidden: 3, Undefined: 0 };
    this.MenuLocation = { AfterWindowsCommands: 23, BeforeProperties: 42, BeforeWindowsCommands: 22, Bottom: 43, CollectionMembersSpecific: 35, DefaultCommand: 20, Deletion: 36, DocumentConversions: 41, Edit: 37, FileCreation: 25, FolderSpecific: 27, HistorySpecific: 33, Misc1_Bottom: 32, Misc1_Middle: 31, Misc1_Top: 30, Misc2_Bottom: 40, Misc2_Middle: 39, Misc2_Top: 38, ObjectCreation: 24, ObjectOperations: 26, PropertyFolder: 44, RelationshipsSpecific: 34, SingleFolderSpecific: 28, Top: 21, ViewVisibility: 29 };
    this.CommandLocation = { All: 268435455, ContextMenu: 2, MainMenu: 1, TaskPane: 4, Undefined: 0 };
    this.ConditionType = { Equal: 1, NotEqual: 2, GreaterThan: 3, LessThan: 4, GreaterThanOrEqual: 5, LessThanOrEqual: 6, Contains: 7, DoesNotContain: 8, StartsWith: 9, DoesNotStartWith: 10, MatchesWildcardPattern: 11, DoesNotMatchWildcardPattern: 12, IsMissing: 13, IsNotMissing: 14, StartsWithAtWordBoundary: 15, ContainsAnyBitwise: 16, DoesNotContainAnyBitwise: 17 };
    this.DataType = { Uninitialized: 0, Text: 1, Integer: 2, Floating: 3, Date: 5, Time: 6, Timestamp: 7, Boolean: 8, Lookup: 9, MultiSelectLookup: 10, Integer64: 11, FILETIME: 12, MultiLineText: 13, ACL: 14 };
    this.StatusType = { CheckedOut: 0, CheckedOutTo: 1, CheckedOutAt: 2, ObjectID: 3, ObjectVersionID: 4, Deleted: 5, ObjectTypeID: 6, IsLatestCheckedInVersion: 7, ExtID: 8, LatestOrSpecific: 9, ObjectTypeAndID: 10, ObjectFlags: 11, OriginalVaultGUID: 12, OriginalObjectType: 13, OriginalObjectID: 14, OriginalObjectIDSegment: 15 };
    this.SearchFlags = { None: 0, LookInAllVersions: 1, ReturnLatestVisibleVersion: 2, LookAllObjectTypes: 4, DisableRelevancyRanking: 16 };
    this.ParentChildBehavior = { IncludeChildValues: 1, IncludeParentValues: 2, None: 0 };
    this.ObjectWindowMode = { Edit: 3, EditApplicationModal: 4, Insert: 0, InsertSaveAsType: 2, InsertSourceFiles: 1 };
    this.LatestSpecificBehavior = {Automatic: 3, Latest: 2 , Normal: 0 , Specific: 1 };
    this.TaskPaneGroup = { GoTo: 3, Main: 4, New: 1, ViewAndModify: 2 };
    this.ProTipObject = "M-Files.Object.ProTip";
    this.TipProperty = "M-Files.Property.Tip";

    // [ true => debugger is launched in the Right Pane || false => Debugger in launched in Pop-up Dashboard]
    this.PaneDebug = paneDebug;    

    // Bind to shell frame.
    this.bind();
}

CustomUxUtil.prototype = {
    bind: function () {
        /// <summary>
        /// Binds all necessary interface objects to Dashboard 
        /// functionality as they become available.
        /// </summary>
        /// <param name="ui" type="MFiles.IShellUI">The current shellUI.</param>

        // create a self scoped variable for us in nested functions.
        var self = this;

        // ensure the ShellUI has been populated        
        if (this.ui && this.PaneDebug != null) {
            // Since we have a ShellUI, we instantiate the DebuggingConsole 
            this.console = new DebuggingConsole(this.ui, this.PaneDebug);
        }

        // Call the Logger ( Debug Console && HTTP Debug )
        this.Log("CustomUxUtil -> bind()");

        // Bind to shelUI start event to determine, if ui functionality should be enabled at all.
        this.ui.Events.Register(this.Events.Started, function () {

            // Call the Logger ( Debug Console && HTTP Debug )
            self.Log("Shell UI -> Started");
        });

        // Bind to Events
        this.ui.Events.Register(
            self.Events.NewShellFrame,
            function (frame) {

                // log the event
                self.Log("New Shell Frame");
             
                // ensure the Vault object is available
                if (self.ui.Vault) {

                    // the vault is available, so we store it locally
                    self.vault = self.ui.Vault;

                    // convenience variable to store the CurrentUserID
                    self.currentUserID = self.ui.Vault.SessionInfo.UserID;

                    // create the ID Resolver object
                    self.vaultID = new VaultID(self.vault);

                    // create a Pro Tips Object to pull tips from.
                    self.proTips = new ProTips(self.vault, self.ProTipObject);
                };

                // store the New Shell Frame locally
                self.frame = frame;

                // Don't proceed if Vault is off-line.
                if (self.vault.ClientOperations.IsOffline()) { return; }

                // Bind to shellFrame's start event
                self.frame.Events.Register(self.Events.Started, function () {

                    // log the started event
                    self.Log("ShellFrame -> Started");

                    // if the debugger should show in the right pane
                    if (self.PaneDebug) {
                        // launch the console in the right pane
                        self.console.launchConsole(self.frame);
                    }

                    self.Log("Calling -> Register Custom Commands");

                    // register any custom commands
                    self.registerCustomCommands();

                    // Register custom command binding
                    self.frame.Commands.Events.Register(
                        self.Events.CustomCommand, 
                        function (cmd) {

                            // Call the Logger ( Debug Console && HTTP Debug )
                            self.Log("Custom Command Triggered: Command ID -> " + cmd);

                            // Call the On Custom Command Event Handler
                            //     => passing the Command ID
                            self.onCustomCommand(cmd);
                        }
                    );

                    // Register built in command event binding
                    self.frame.Commands.Events.Register(
                        self.Events.BuiltInCommand,
                        function(command) {
                            // As this handler is triggered for all Built In Commands
                            // we have to determine how we want to handler this 
                            // specific command based on its command id

                            // ############################################################
                            // If the user has clicked => AddToFavorites
                            // ############################################################
                            if (command === self.BuiltInCommands.AddToFavorites) {

                                // Show a simple alert message.
                                self.Alert("Adding favorites is disabled.");

                                // return false to prevent further execution of this event
                                return false;
                            }

                            // ############################################################
                            // If the user has clicked => Copy
                            // ############################################################
                            if (command === self.BuiltInCommands.Copy) {                                

                                // create an enum-like object for improved read-ability
                                var choice = { Cancel: 1, Copy: 2 };

                                // return a specific tip
                                var tipOne = self.proTips.getTip(1);

                                // Show a Message to the user about M-Files Best Practices
                                var answer = self.Message(
                                    tipOne.Title,    // caption
                                    self.getPropText(tipOne, self.TipProperty),   // message
                                    "information",      // icon
                                    "Cancel Copy",      // button 1 text
                                    "Copy Anyway!",     // button 2 text
                                    choice.Copy,        // default button
                                    choice.Cancel,      // timeout button
                                    15                  // timeout seconds
                                );

                                // if the user chose to cancel => return false to prevent 
                                // further execution of this event
                                if (answer === choice.Cancel) {return false;};
                            }

                            // ############################################################
                            // If the user has clicked => Show History
                            // ############################################################
                            if (command === self.BuiltInCommands.ShowHistory) {

                                // return a specific tip
                                var tip18 = self.proTips.getTip(18);

                                // Show a pop-up dashboard message, with pro tip 
                                // 178 ( as it is related to the showing the history )
                                self.PopupMessage(tip18.Title, self.getPropText(tip18, self.TipProperty));

                                // return early by returning true while maintaining 
                                // the normal event processing
                                return true;
                            }

                            // ############################################################
                            // For All Other Built In Commands
                            // ############################################################
                            else {
                                // Note: failure to return true or false will result in 
                                // the default processing to continue.  You must explicitly
                                // return false in order to prevent default processing.
                                //
                                // return true to allow built in processing to continue
                                return true;
                            }
                        }
                    );
                }
            );
        });
    },

    getProps: function(objectVersion) {
        return this.vault.ObjectPropertyOperations.GetProperties(objectVersion.ObjVer, true);
    },

    getPropText: function (objectVersion, propAlias) {
        var propID = this.vault.PropertyDefOperations.GetPropertyDefIDByAlias(propAlias);
        var props = this.getProps(objectVersion);

        // see if the property exists
        if (props.IndexOf(propID) !== -1) {
            // the property exists
            return props.SearchForProperty(propID).GetValueAsLocalizedText();
        } else {
            return "null";
        }
    },

    onCustomCommand: function( command ) {
        /// <summary>Custom Commands Event Handler</summary>
        /// <param name="command" type="number">Custom Command ID</param> 

        this.Log("Reset Tips -> Alert Displayed");
        
        // ############################################################
        // User clicked => Reset Tasks
        // ############################################################
        if (command === this.resetTipsCmd) {

            this.Log("Reset Tips -> Clicked");
            
            // it was => so we write an empty Array = []
            this.WriteTips([]);

            // give the user some feedback
            this.Alert("Learned Tips Cleared!");

            this.Log("Reset Tips -> Alert Displayed");
        }

        // ############################################################
        // User clicked => View Tip
        // ############################################################
        else if (command === this.viewTipCmd) {
            this.Log("View Tips -> Clicked");

            // read current tips
            var learnedTips = this.ReadTips();

            // get a random tip to display
            var tip = this.proTips.random(learnedTips);

            // show an alert
            this.Alert(tip.Title + "\n" + this.getPropText(tip, self.TipProperty));

            this.Log("View Tips -> Alert Displayed");
        }
    },

    registerCustomCommands: function () {
        /// <summary>Adds a Clear Tips Custom Command to the Context Menu.</summary>
        /// <param name="shellFrame" type="MFiles.ShellFrame">The new shell frame object.</param> 
        this.Log("Register Custom Commands-> Entery");


        this.resetTipsCmd = this.addCommand("Reset Tips", "util/img/reset.ico", this.MenuLocation.Bottom, this.TaskPaneGroup.Main);
        this.Log("Registered Custom Command: Reset Tips -> " + this.resetTipsCmd);

        this.viewTipCmd = this.addCommand("View Tip", "util/img/learn.ico", this.MenuLocation.Bottom, this.TaskPaneGroup.Main);
        this.Log("Registered Custom Command: View Tip -> " + this.viewTipCmd);
    },

    addCommand: function (caption, iconPath, menuLocation, taskPaneGroup) {
        // Create a command.
        var cmd = this.frame.Commands.CreateCustomCommand(caption);

        // ensure a icon path was passed
        if (typeof iconPath === "string" ) {
            // Set command icon.
            this.frame.Commands.SetIconFromPath(cmd, iconPath);
        }

        if (menuLocation) {
            // Add a command to the context menu.
            this.frame.Commands.AddCustomCommandToMenu(cmd, menuLocation, 0);
        }

        if (taskPaneGroup) {
            // Add a commands to the task pane.
            this.frame.TaskPane.AddCustomCommandToGroup(cmd, taskPaneGroup, -101);
        }

        return cmd;
    },

    Create: function (type) {
        /// <summary>
        /// Convenience method to create a new instance of a M-Files Object.
        /// </summary>
        /// <param name='type' type='string'>Type name of the object to create: ie. 'ObjVer', 'Lookup' or 'PropertyValue'.</param>

        // ensure we are inside a UX-App environment
        if (MFiles) {
            return MFiles.CreateInstance(type);
        };

        // return null as we are not inside an M-Files env
        return null;
    },

    mfLink: function(objVer) {
        /// <summary>
        /// Gets the Path in the Default View via an ObjVer.
        /// </summary>
        /// <param name="objVer" type="MFilesAPI.ObjVer">ObjVer of the Object you with to Get the Path in the Default view</param>

        // get the ObjectVersion
        var ov = this.vault.ObjectOperations.GetObjectInfo(objVer, true, true);
        // convert it to an MFLink
        var mflink = this.vault.ObjectFileOperations.GetPathInDefaultView(ov.ObjVer.ObjID, -1, -1, -1);
        // return mflink
        return mflink;
    },

    openLink: function (objVer) {
        /// <summary>
        /// Opens an ObjVer in M-Files Client.
        /// </summary>
        /// <param name="objVer" type="MFilesAPI.ObjVer">ObjVer of the Object you with to open in the Client View</param>

        // get the mflink
        var mflink = this.mfLink(objVer);
        // parse this and build the actual mflink
        this.frame.CurrentPath = this.parsePath(mflink);
    },

    callExtMethodAsync: function (params, successFn, errorFn) {
        /// <summary>
        ///  Calls the Server App extension method asynchronously with the passed params.
        /// </summary>
        /// <param name="params" type="Array" targetType="string">String params to pass to the extension method</param>
        /// <param name="successFn" type="function()" >Function to execute on a successful return result</param>
        /// <param name="errorFn" type="function()">Function to execute on error</param>

        // Convert parameters to formatted json string.
        var json = JSON.stringify(params, null, 4);

        // Call the Logger ( Debug Console && HTTP Debug )
        this.Log("Executing Asynchronously: " + json);

        // Call the extension method.
        this.vault.Async.ExtensionMethodOperations.ExecuteVaultExtensionMethod(
            this.ServerApp_Namespace,
            json,
            function (responseString) {
                // Use the callback success function.
                successFn(responseString);
            },
            function (exception) {
                // Use the callback error function.
                errorFn(exception);
            }
       );
    },

    callExtMethod: function (params) {
        /// <summary>
        ///  Calls the Server App extension method with the passed params.
        /// </summary>
        /// <param name="params" type="Array" targetType="string">String params to pass to the extension method</param>
        /// <returns type="string"></returns>

        // Convert parameters to a formatted json string
        var json = JSON.stringify(params, null, 4);
 
        // Call the Logger ( Debug Console && HTTP Debug )
        this.Log("Executing: " + json);

        // Call the extension method.
        var output = this.vault.ExtensionMethodOperations.ExecuteVaultExtensionMethod(
            this.ServerApp_Namespace,
            json
        );

        // Call the Logger ( Debug Console && HTTP Debug )
        this.Log("Output: " + JSON.parse(output, null, 4 ) );
        
        // return the output string
        return output;
    },

    objVerToString: function (objVer) {
        /// <summary>
        ///  Converts an ObjVer to a formatted string: ie ( Document-ID 123-Version 4) => (0-123-4)
        /// </summary>
        /// <param name="objVer" type="MFilesAPI.ObjVer">ObjVer you wish to format</param>
        return "(" + objVer.Type + "-" + objVer.ID + "-" + objVer.Version + ")";
    },

    parseObjVer: function (value) {
        /// <summary>
        ///  Converts a formatted ObjVer string to a valid ObjVer object
        /// </summary>

        // remove the opening and closing Parenthesis
        value = value.replace("(", "").replace(")", "");

        // split by the hyphen sign
        var ids = value.split("-");

        // create a new MFilesApi.ObjVer instance 
        var objVer = MFiles.CreateInstance("ObjVer");
        // set the IDs based on the parsed strings values
        objVer.SetIDs(parseInt(ids[0]), parseInt(ids[1]), parseInt(ids[2]));

        // return the fully populated ObjVer object
        return objVer;
    },

    parsePath: function (fullpath) {
        /// <summary>
        /// Parses an un-sanitized MF-Link path to a usable MF-Link.
        /// </summary>
        /// <param name="fullpath" type="string">Un-Sanitized MF-Link ( Direct from API )</param>

        // split the parts 
        var parts = fullpath.split("\\");
        
        // return just the usable splice
        return parts.splice(2, (parts.length - 3)).join("\\");
    },

    EmptyMessage: function () {
        /// <summary>
        /// Convenience method to create a new instance of a M-Files Message Object.
        /// </summary>
        return {
            caption: "Default",
            message: null,
            icon: "warning",
            button1_title: "Ok",
            button1_enabled: true,
            button2_title: null,
            button3_title: null,
            button3_enabled: true,
            button4_title: null,
            button4_enabled: true,
            defaultButton: 1,
            cancelButton: 0,
            timeOutButton: 0,
            timeOut: 0,
            timeout_deactivateOnFocusChange: true,
            checkbox_title: null,
            checkbox_enabled: true,
            checkbox_checked: false
        };
    },

    Log: function (message) {
        /// <summary>
        /// Convenience method to Send logging data to the HTTP Debugger and the pop-up Debugger Console.
        /// </summary>
        /// <param name='message' type='string'>String message to send</param>
        
        // ensure that the WebClient Object was created successfully
        if (this.webClientLite) {
            // send a HTTP GET request to the HTTP Debugger
            this.webClientLite.Get("http://localhost:8080/debug?data=" + message);
        }

        // Send logging data to the pop-up Debugger Console
        this.Debug(message);
    },

    Debug: function (message) {
        /// <summary>
        /// Convenience method to Send logging data to the pop-up Debugger Console
        /// </summary>
        /// <param name='message' type='string'>String message to send to the debugger</param>

        // ensure the pop-up Debugger Console was created successfully
        if (this.console) {
            // call the log function on the pop-up Debugger Console
            this.console.log(message);
        }
    },

    Alert: function (message) {
        /// <summary>
        /// Convenience method to show a simple message box to the user.
        /// </summary>
        /// <param name='message' type='string'>String message to show</param>

        // ensure the ShellFrame has been populated successfully
        if(this.frame) {
            // Call ShellFrame.ShowMessage
            this.frame.ShowMessage(message);
        }
    },

    Message: function (caption, message, icon, button1_title, button2_title, defaultButton, timeOutButton, timeOut) {
        /// <summary>
        /// Convenience method to show a complex message to the user.
        /// </summary>
        /// <param name='caption' type='string'>Message window caption text</param>
        /// <param name='message' type='string'>Message window context text</param>
        /// <param name='icon' type='string'>"error" || "warning" || "information" || "question"</param>
        /// <param name='button1_title' type='string'>Button 1 title - Default => Ok</param>
        /// <param name='button2_title' type='string'>Button 2 title - Default => null</param>
        /// <param name='defaultButton' type='number'>Number representation of the Default Button: ie 1 || 2</param>
        /// <param name='timeOutButton' type='number'>Button to select on timeout</param>
        /// <param name='timeOut' type='number'>number of seconds to use as the timeout value</param>
        
        // create a partially populated message object
        var m = {
            caption: caption,
            message: message,
            icon: icon,
            button1_title: button1_title,
            button2_title: button2_title,
            defaultButton: defaultButton,
            timeOutButton: timeOutButton,
            timeOut: timeOut
        };

        // ensure the ShellFrame has been populated successfully
        if (this.frame) {
            // Call the ShellFrame.ShowMessage function
            return this.frame.ShowMessage(m);
        }

        // there was no ShellFrame, so simply return null
        return null;
    },

    PopupMessage: function (caption, message) {
        /// <summary>
        /// Convenience method to show a pop-up dashboard message to the user.
        /// </summary>
        /// <param name='caption' type='string'>Message window caption text</param>
        /// <param name='message' type='string'>Message text</param>
        
        // show the pop-up message dashboard
        this.frame.ShowPopupDashboard(
            "popup_message",
            true,
            { caption: caption, message: message }
        );
    },

    ReadTips: function () {
        /// <summary>
        /// Convenience method to Read the Learned Tips from the Registry.
        /// </summary>

        this.Log("Read Tips -> Entry");

        // ensure we are inside a UX-App environment
        if (MFiles) {
            // Read the tipIds string from the registry, return the JSON.parsed Array[]
            var tips = MFiles.ReadFromRegistry(true, "pro-tips", "learned-tips");

            this.Log("Tips -> " + tips);

            if (tips) {
                // split by comma and convert to an int[]
                var resultArray = tips.split(',');

                this.Log("Tips[] -> " + resultArray.toString());

                // convert our string[] to an int[]
                var intArray = [];
                for (var i = 0; i < resultArray.length; i++) {
                    intArray.push(parseInt(resultArray[0]));
                }

                return intArray;
            }

            // no results by now, return an empty array
            return [];
        } else {
            this.Log("MFiles Object -> Unavailable");
        }
    },

    WriteTips: function ( tipIds ) {
        /// <summary>
        /// Convenience method to Write Learned Tips to the Registry.
        /// </summary>
        /// <param name="tipIds" type="Array" targetType="number">Array [] of Tip IDs</param> 

        this.Log("Read Tips -> Entry");

        // ensure we are inside a UX-App environment
        if(MFiles) {

            var cleanArr = this.deDupe(tipIds);

            var tipStr = cleanArr.toString();

            this.Log("Write Tips -> " + tipStr);

            // Write the tipIds array as JSON to the registry
            MFiles.WriteToRegistry(
                true,
                "pro-tips",
                "learned-tips",
                tipStr,
                "REG_SZ"
            );
        } else {
            this.Log("MFiles Object -> Unavailable");
        }
    },

    deDupe: function (arr) {
        var i, len = arr.length, out = [], obj = {};

        // loop over the indexes, creating an object
        for (i = 0; i < len; i++) {
            if (typeof arr[i] === "undefined" || arr[i] == null) { continue; }
            obj[arr[i]] = 0;
        }

        // loop over the unique keys
        for (i in obj) {
            if ( typeof i === "undefined" || i == null ) {continue;}
            out.push(i);
        }

        return out;
    }
};