function ProTips(vault, proTipObjectAlias) {
    this.vault = vault;
    this.proTipObjectID = this.vault.ObjectTypeOperations.GetObjectTypeIDByAlias(proTipObjectAlias);

    this.StatusType = { CheckedOut: 0, CheckedOutTo: 1, CheckedOutAt: 2, ObjectID: 3, ObjectVersionID: 4, Deleted: 5, ObjectTypeID: 6, IsLatestCheckedInVersion: 7, ExtID: 8, LatestOrSpecific: 9, ObjectTypeAndID: 10, ObjectFlags: 11, OriginalVaultGUID: 12, OriginalObjectType: 13, OriginalObjectID: 14, OriginalObjectIDSegment: 15 };
    this.ConditionType = { Equal: 1, NotEqual: 2, GreaterThan: 3, LessThan: 4, GreaterThanOrEqual: 5, LessThanOrEqual: 6, Contains: 7, DoesNotContain: 8, StartsWith: 9, DoesNotStartWith: 10, MatchesWildcardPattern: 11, DoesNotMatchWildcardPattern: 12, IsMissing: 13, IsNotMissing: 14, StartsWithAtWordBoundary: 15, ContainsAnyBitwise: 16, DoesNotContainAnyBitwise: 17 };
    this.DataType = { Uninitialized: 0, Text: 1, Integer: 2, Floating: 3, Date: 5, Time: 6, Timestamp: 7, Boolean: 8, Lookup: 9, MultiSelectLookup: 10, Integer64: 11, FILETIME: 12, MultiLineText: 13, ACL: 14 };
    this.SearchFlags = { None: 0, LookInAllVersions: 1, ReturnLatestVisibleVersion: 2, LookAllObjectTypes: 4, DisableRelevancyRanking: 16 };

    return this;
};

ProTips.prototype = {
    create: function(type) {
        return MFiles.CreateInstance(type);
    },

    // ################################################################################################################
    // ################################################### Get Random #################################################
    random: function(exclude) {
        /// <summary>
        /// Gets a random tip from the ProTips Object.  Excluding any Tip IDs passed in the exclude Array []
        /// </summary>
        /// <param name="exclude" type="Array" targetType="number">Array [] of Tip IDs to exclude from the random pool</param> 
        'use strict';

        var cleanArr = this.deDupe(exclude);

        var searchConditions = this.create("SearchConditions");

        var typeCondition = this.create("SearchCondition");
        typeCondition.Expression.SetStatusValueExpression(this.StatusType.ObjectTypeID, this.create("DataFunctionCall"));
        typeCondition.ConditionType = this.ConditionType.Equal;
        typeCondition.TypedValue.SetValue(this.DataType.Lookup, this.proTipObjectID);

        searchConditions.Add(-1, typeCondition);

        var excludeCondition = this.create("SearchCondition");
        excludeCondition.Expression.SetStatusValueExpression(this.StatusType.ObjectID, this.create("DataFunctionCall"));
        excludeCondition.ConditionType = this.ConditionType.NotEqual;

        for (var i = 0; i < cleanArr.length; i++) {
            var id = cleanArr[i];

            $mf.Log("Excluding: " + id);

            excludeCondition.TypedValue.SetValue(this.DataType.Integer, parseInt(id));
            searchConditions.Add(-1, excludeCondition);
        }

        var results = this.vault.ObjectSearchOperations.SearchForObjectsByConditionsEx(searchConditions, this.SearchFlags.None, false, 0, 30).GetAsObjectVersions();

        $mf.Log("Random Result Count: " + results.Count);

        var returnIndex = Math.random() * (results.Count - 1) + 1;

        $mf.Log("Returning Random Index: " + returnIndex);

        $mf.Log("Returning Random: " + results[returnIndex].Title);

        return results[returnIndex];
    },

    // ################################################################################################################
    // ################################################### Get by ID ##################################################
    getTip: function(id) {
        var objVer = this.create("ObjVer");
        objVer.SetIDs(this.proTipObjectID, id, -1);

        return this.vault.ObjectOperations.GetObjectInfo(objVer, true, true);
    },

    deDupe: function (arr) {
        var i, len = arr.length, out = [], obj = {};

        // loop over the indexes, creating an object
        for (i = 0; i < len; i++) {
            if (typeof arr[i] === "undefined" || arr[i] == null) { continue; }
            obj[arr[i]] = 0;
        }

        // loop over the unique keys
        for (i in obj) {
            if (typeof i === "undefined" || i == null) { continue; }
            out.push(i);
        }

        return out;
    }
};