﻿function DebuggingConsole(shellUI, paneDebug) {
	this.ui = shellUI;
	this.buffer = [];
    this.lauched = false;
    this.PaneDebug = paneDebug;
	var self = this;

    // if this is not going to launch in the right pane... show the pop-up
	if (!this.PaneDebug) {
	    // bind to shellUI start event
	    shellUI.Events.Register(Event_Started, function () {
	        self.launchConsole(null);
	    });
    }

    this.launchConsole = function(frame) {
        if (!this.lauched) {
            var customData = {
                registerLoggingFunction: function(f) {
                    // register the function
                    self.dashboardLog = f;
                    self.dashboardLog("Console loaded. version 0.1a");
                    // purge the buffer.
                    for (var i = 0; i < self.buffer.length; i++) {
                        self.log(self.buffer[i]);
                    }
                }
            };

            if (!this.PaneDebug) {
                // show the pop-up dashboard
                this.tab = this.ui.ShowPopupDashboard("console", false, customData);
            } else {
                // add the dashboard tab
                this.tab = frame.RightPane.AddTab("_debug", "Debugger", "_last");

                // show the dashboard
                this.tab.ShowDashboard("console", customData);

                // and set its visibility to true
                this.tab.Visible = true;

                // select this tab
                this.tab.Select();
            }
        }

        this.lauched = true;
    };

    this.log = function(msg) {
        if (this.dashboardLog) {
            try {
                this.dashboardLog(msg);
            } catch (e) {
            }
        } else {
            this.buffer.push(msg);
        }
    };

    this.stringify = function (obj) {
        var str = "{\n";
        for (var p in obj) {
            //Skip functions
            if (obj[p] && ({}).toString.call(obj[p]) == '[object Function]')
                continue;
            str += "  " + p + ": " + obj[p] + "\n";
        }
        str += "}";
        this.log(str);
    };


    this.dump = function(name, obj)
    {
        var str = name + ": {\n";
        for(var p in obj) {
            //Skip functions
            if( obj[p] && ({}).toString.call(obj[p]) == '[object Function]' )
                continue;
            str += "  " + p + ": " + obj[p] + "\n";
        }
        str += "}";
        this.log(str);
    };
}