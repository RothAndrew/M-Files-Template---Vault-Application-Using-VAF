var $mf = null;

function OnNewShellUI( shellUI )
{
    /// <summary>The entry point of ShellUI module.</summary>
    /// <param name="shellUI" type="MFiles.ShellUI">The new shell UI object.</param> 
    'use strict';

    // Objects to increase readability
    var debugIn = { RightPane: true, PopupDashboard: false, Disabled: null };
    var httpDebugger = { Enabled: true, Disabled: false };

    // Create the UX-Utility
    $mf = new CustomUxUtil(shellUI, null, debugIn.Disabled, httpDebugger.Disabled);
}