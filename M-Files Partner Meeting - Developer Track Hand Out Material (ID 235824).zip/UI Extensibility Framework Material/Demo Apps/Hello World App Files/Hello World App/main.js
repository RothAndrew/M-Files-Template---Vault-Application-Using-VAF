function OnNewShellUI( shellUI )
{
    // Return event handlers as a closure.
    return {
           OnStarted: function() {
           // Handle the started event of ShellUI.
           },
           OnNewShellFrame: function( shellFrame ) {
           // Handle the OnNewShellFrame event of ShellUI.
                 return {
                       OnStarted: function() {
                       // Handle the started event of ShellFrame.
                       		shellFrame.ShowMessage("Hello World!")
                       }
                 };
           }
   };
}