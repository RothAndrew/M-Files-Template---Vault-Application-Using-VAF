"use strict";

function OnNewShellUI(shellUI) {
    // Return event handlers as a closure.
    return {
        OnStarted: function() {
            // Handle the started event of ShellUI.
        },
        OnNewShellFrame: function(shellFrame) {
            // Handle the OnNewShellFrame event of ShellUI.
            return {
                OnStarted: function() {
                    // Handle the started event of ShellFrame.


                     // We want to register a listern for the OnNewShellListing Event
                     // we do this so we can see what the user has selected in the shell listing
                     shellFrame.Events.Register(
                     	Event_NewShellListing, 
                     	function(shellListing) { 
                     		// we are inside the new shell listing 

                     		// we also need to listen to the OnSelectionChanged Event
                     		// so we know when a new item has been selected 
                     		shellListing.Events.Register(
                     			Event_SelectionChanged,
								function(selectedItems) {
									// Note: M-Files Collections are '1' indexed...
									// I know... But they are.
									var objectVersion = selectedItems.ObjectVersions.Item(1);
									if( objectVersion.ObjVer.Type == 0 ) { 
										// if the selected object is of type = Document
										// do something
										shellFrame.ShowMessage("You selected a Document");
									}
								} 
                     		)
                     	});
















                    // Create a command.
                    var myCmd = shellFrame.Commands.CreateCustomCommand("Hello");

                    // Set command icons.
                    shellFrame.Commands.SetIconFromPath(myCmd, "ico/lightbulb.ico");

                    // Add a command to the context menu.
                    shellFrame.Commands.AddCustomCommandToMenu(
                    	myCmd, 
                    	MenuLocation_ContextMenu_Bottom, 
                    	0
                    );

                    // Add a commands to the task pane.
                    shellFrame.TaskPane.AddCustomCommandToGroup(
                    	myCmd, 
                    	TaskPaneGroup_Main, 
                    	-101
                    );

                    // Set the command handler => function closure.
                    shellFrame.Commands.Events.Register(
                        Event_CustomCommand, 
                        function(command) {
                            // execute code only for a specific command.
                            if (command === myCmd) {
                                // Show a message.
                                shellFrame.ShowMessage("World!");
                            }
                        }
                    );
                }
            };
        }
    };
}