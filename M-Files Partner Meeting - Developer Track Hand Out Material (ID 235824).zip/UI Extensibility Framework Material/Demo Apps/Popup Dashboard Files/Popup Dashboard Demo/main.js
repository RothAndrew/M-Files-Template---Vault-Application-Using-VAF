
"use strict";

function OnNewShellUI( shellUI ) {
	/// <summary>The entry point of ShellUI module.</summary>
	/// <param name="shellUI" type="MFiles.ShellUI">The new shell UI object.</param> 

	// Register to listen new shell frame creation event.
	shellUI.Events.Register( Event_NewShellFrame, newShellFrameHandler );
}

function newShellFrameHandler( shellFrame ) {
	/// <summary>Handles the OnNewShellFrame event.</summary>
	/// <param name="shellFrame" type="MFiles.ShellFrame">The new shell frame object.</param> 

	// Register to listen the started event.
	shellFrame.Events.Register( Event_Started, getShellFrameStartedHandler( shellFrame ) );
}

function getShellFrameStartedHandler( shellFrame ) {
	/// <summary>Gets a function to handle the Started event for shell frame.</summary>
	/// <param name="shellFrame" type="MFiles.ShellFrame">The current shell frame object.</param> 
	/// <returns type="MFiles.Events.OnStarted">The event handler.</returns>

	// Return the handler function for Started event.
	return function() {
	
		// Shell frame object is now started.
		
		// Create some commands.
		var cmdHome = shellFrame.Commands.CreateCustomCommand( "Hello World" );
		var cmdLocal = shellFrame.Commands.CreateCustomCommand( "Hello Local" );

		// Set command icons.
		shellFrame.Commands.SetIconFromPath( cmdHome, "ico/globe.ico" );
		shellFrame.Commands.SetIconFromPath( cmdLocal, "ico/home.ico" );
		
		// Add a command to the context menu.
		shellFrame.Commands.AddCustomCommandToMenu( cmdHome, MenuLocation_ContextMenu_Bottom, 0 );
		shellFrame.Commands.AddCustomCommandToMenu( cmdLocal, MenuLocation_ContextMenu_Bottom, 0 );
		
		// Add a commands to the task pane.
		shellFrame.TaskPane.AddCustomCommandToGroup( cmdHome, TaskPaneGroup_Main, -100 );
		shellFrame.TaskPane.AddCustomCommandToGroup( cmdLocal, TaskPaneGroup_Main, -101 );
		
		// Set the command handler function.
		shellFrame.Commands.Events.Register( Event_CustomCommand, function( command ) {		
			// Branch by command.
			if( command == cmdHome ) {
				// Show a message.
				shellFrame.ShowPopupDashboard(
					"popup_message",
					true, 
					{ caption: "Hello!", message: "Hello World" } );
			} else if( command == cmdLocal ) {			
				// Show a message.
				shellFrame.ShowPopupDashboard(
					"popup_message",
					true, 
					{ caption: "Hello!", message: "Hello San Diego" } );
			}
		} );
	};
}
