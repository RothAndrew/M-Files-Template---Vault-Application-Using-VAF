
"use strict";

function OnNewShellUI( shellUI ) {
	/// <summary>The entry point of ShellUI module.</summary>
	/// <param name="shellUI" type="MFiles.ShellUI">The new shell UI object.</param> 

	// Register to listen new shell frame creation event.
	shellUI.Events.Register( Event_NewShellFrame, newShellFrameHandler );
}

function newShellFrameHandler( shellFrame ) {
	/// <summary>Handles the OnNewShellFrame event.</summary>
	/// <param name="shellFrame" type="MFiles.ShellFrame">The new shell frame object.</param> 

	// Register to listen the started event.
	shellFrame.Events.Register( Event_Started, getShellFrameStartedHandler( shellFrame ) );
}

function getShellFrameStartedHandler( shellFrame ) {
	/// <summary>Gets a function to handle the Started event for shell frame.</summary>
	/// <param name="shellFrame" type="MFiles.ShellFrame">The current shell frame object.</param> 
	/// <returns type="MFiles.Events.OnStarted">The event handler.</returns>

	// Return the handler function for Started event.
	return function() {
	
		// Shell frame object is now started.
		
		// Create a command.
		var cmdLaunch = shellFrame.Commands.CreateCustomCommand( "Lanch Pane" );

		// Set command icons.
		shellFrame.Commands.SetIconFromPath( cmdLaunch, "ico/monitor.ico" );
		
		// Add a command to the context menu.
		shellFrame.Commands.AddCustomCommandToMenu( cmdLaunch, MenuLocation_ContextMenu_Bottom, 0 );
		
		// Add a commands to the task pane.
		shellFrame.TaskPane.AddCustomCommandToGroup( cmdLaunch, TaskPaneGroup_Main, -100 );
		
		// Set the command handler function.
		shellFrame.Commands.Events.Register( Event_CustomCommand, function( command ) {		
			// Branch by command.
			if( command == cmdLaunch ) {
                // add the dashboard tab
                var tab = shellFrame.RightPane.AddTab("right_pane", "Right Pane App", "_last");

                // show the dashboard
                tab.ShowDashboard("right_pane", { self: tab, caption: "Right Pane", message: "This is a right pane dashboard" });

                // and set its visibility to true
                tab.Visible = true;

                // select this tab
                tab.Select();
            }
		} );
	};
}
