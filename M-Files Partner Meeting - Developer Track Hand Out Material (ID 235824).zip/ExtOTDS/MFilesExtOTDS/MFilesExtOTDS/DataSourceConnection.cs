﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using MFiles.Server.Extensions;
using MFilesAPI;

namespace MFilesExtOTDS
{
	public class DataSourceConnection : IDataSource, IDataSourceConnection
    {
		Dictionary<int, PropertyDef> propertyDefsDictionary;
		private Vault vault;
		private int[] columnOrdinals;

		#region IDataSource Members

		public bool CanAlterData()
		{
			return false;
		}

		public IDataSourceConnection OpenConnection( string connectionString, Guid configurationId )
		{
			System.Diagnostics.Debugger.Launch();

			return this;
		}

		#endregion

		#region IDataSourceConnection Members

		public bool CanGetOneItem()
		{
			return false;
		}

		public void CloseConnection()
		{
			
		}

		public void CompletedDataRetrieval()
		{
			
		}

		public IEnumerable<ColumnDefinition> GetAvailableColumns()
		{
			MFilesServerApplication server = new MFilesServerApplication();
			server.Connect( MFAuthType.MFAuthTypeSpecificMFilesUser, "Test", "t" );
			this.vault = server.LogInToVault( "{D5FAFBF2-CBD6-4FEA-A832-D40F512853AE}" );

			int ordinal = 1;

			yield return new ColumnDefinition()
			{
				Name = "ID",
				Ordinal = ordinal,
				Type = typeof( string )
			};

			this.propertyDefsDictionary = new Dictionary<int, PropertyDef>();
			foreach( PropertyDef propDef in vault.PropertyDefOperations.GetPropertyDefs() )
			{
				ordinal++;
				this.propertyDefsDictionary.Add( ordinal, propDef );

				yield return new ColumnDefinition()
				{
					Name = propDef.Name,
					Ordinal = ordinal,
					Type = typeof( string )
				};
			}
		}

		public IEnumerable<DataItem> GetItems()
		{
			string connString = "04006000001000000R00000100000G840000200000000000000000000000008000002000000G0000001000009404R002000001G000006000002G0000040000000000000000002000000G000010000000001000000R000003000001G0000020000000000000000001000000800000J0000000600000100000YQZZZZW8000005G00005603501GG0WG0CC06G01001QG0UG0DG07J01T00G00GR0EM07603M01QG0U80CM07403K00000000000000000000000000000000000000000000007ZZZZZY";

			ObjectSearchResults results = this.vault.ObjectSearchOperations.SearchForObjectsByConditions( 
				GetSearchConditionsBySearchString( connString ), 
				MFSearchFlags.MFSearchFlagDisableRelevancyRanking, 
				false 
			);

			ObjectVersionAndPropertiesOfMultipleObjects ovapomo = vault.ObjectOperations.GetObjectVersionAndPropertiesOfMultipleObjects( 
				results.GetAsObjectVersions().GetAsObjVers(), 
				true, 
				false, 
				true, 
				true 
			);

			foreach( ObjectVersionAndProperties ovap in ovapomo )
			{
				Dictionary<int, object> itemValueDictionary = new Dictionary<int, object>();

				itemValueDictionary.Add( 1, ovap.ObjVer.ID.ToString() );

				foreach( var ordinalAndPropertyDef in propertyDefsDictionary )
				{
					int index = ovap.Properties.IndexOf( ordinalAndPropertyDef.Value.ID );

					if( index == -1 )
						continue;

					string propertyValue = ovap.Properties[ index ].GetValueAsUnlocalizedText();

					itemValueDictionary.Add( ordinalAndPropertyDef.Key, propertyValue );
				}

				yield return new DataItemSimple( itemValueDictionary );
			}
		}

		private SearchConditions GetSearchConditionsBySearchString( string connString )
		{
			SearchConditions conds = new SearchConditions();
			conds.AppendFromExportedSearchString( connString );
			return conds;
		}

		public DataItem GetOneItem( int columnOrdinalExtID, string externalID )
		{
			return null;
		}

		public void Interrupt()
		{
			
		}

		public void PrepareForDataRetrieval( string selectStatement )
		{

		}

		public void SetColumnsToRetrieve( int[] columnOrdinals )
		{
			this.columnOrdinals = columnOrdinals;
		}

		#endregion
	}
}
